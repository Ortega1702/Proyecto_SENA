<?php
$servername = "127.0.0.1:3307";
$username = "root"; 
$password = "admin"; 
$dbname = "proyecto_sena";

// Crea la conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica si la conexión es exitosa
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>
