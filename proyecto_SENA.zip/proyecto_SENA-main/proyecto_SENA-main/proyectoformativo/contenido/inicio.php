<!DOCTYPE html>
<html lang="en">
    
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Inicio de sesión</title>
        <link rel="stylesheet" href="../css/inicio_sesion.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    </head>
    
    <body>
      <?php
        session_start();

        if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
            header('Location: inicio.php'); // Si no ha iniciado sesión, redirige al formulario de inicio de sesión
            exit();
        }

        if (isset($_SESSION['mensaje'])) {
            echo "<script>alert('" . $_SESSION['mensaje'] . "')</script>";
            unset($_SESSION['mensaje']); // Elimina el mensaje de la sesión para que no se muestre de nuevo
        }
      ?>
        <main>
    <div class="inicio_sesion">
      <img src="../images/logo.png" class="logo1 m-3" alt="">
      <div class="card" style="width: 18rem;">
        <div class="card-body text-center">
          <form action="procesar_inicio_sesion.php" method="post" class="needs-validation" novalidate>
            <div class="mb-3">
              <label for="exampleInputEmail1" class="form-label">Usuario o email</label>
              <input type="text" class="form-control" id="exampleInputEmail1" name="usuario" aria-describedby="emailHelp"
                id="validationCustomUsername" aria-describedby="inputGroupPrepend" required>
            </div>
            <div class="mb-3">
              <label for="exampleInputPassword1" class="form-label">Contraseña</label>
              <input type="password" class="form-control" id="exampleInputPassword1" name="contrasena" id="validationCustomUsername"
                aria-describedby="inputGroupPrepend" required>
              <div id="emailHelp" class="form-text mt-3"><a href="../contenido/olvido.php"
                  class="text-decoration-none text-black">Olvido su contraseña?.</a></div>
              <div id="emailHelp" class="form-text mt-3"><a href="../contenido/registro.php"
                  class="text-decoration-none text-black">No tienes una cuenta? Registrate ya!.</a></div>
            </div>
            <button type="submit" id="submitButton" disabled class="btn botonv">Entrar</button>
          </form>
        </div>
      </div>
    </div>
  </main>


  <script src="../js/code.jquery.com_jquery-3.7.0.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    
    const formulario = document.querySelector(".needs-validation");
    const botonEnviar = document.getElementById("submitButton");

    formulario.addEventListener("input", function () {
      // Verifica si el formulario es válido
      const formularioValido = formulario.checkValidity();

      // Habilita o deshabilita el botón según el estado del formulario
      botonEnviar.disabled = !formularioValido;
    });

    document.addEventListener('DOMContentLoaded', function() {
      // Limpia el campo de correo electrónico si hay un mensaje de sesión
      var emailField = document.querySelector('input[name="usuario"]');
      if (emailField) {
          emailField.value = '';
      }
    });
  </script>
</body>

</html>