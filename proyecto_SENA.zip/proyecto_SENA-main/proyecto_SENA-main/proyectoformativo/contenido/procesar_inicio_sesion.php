<?php
session_start();

// Incluir el archivo de conexión a la base de datos
require_once 'conexion.php';

// Obtener los datos del formulario
$usuario = $_POST['usuario'];
$contrasena = $_POST['contrasena'];

// Consulta para verificar las credenciales del usuario
$sql = "SELECT * FROM usuarios WHERE (usuario='$usuario' OR email='$usuario') AND contrasena='$contrasena'";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
    // Inicio de sesión exitoso
    $_SESSION['loggedin'] = true;
    $_SESSION['email'] = $email;
    $_SESSION['mensaje'] = 'Inicio de sesión exitoso';
    header('Location: dispositivos.php'); // Redirige al usuario a la página de inicio
    exit();
} else {
    // Credenciales incorrectas
    $_SESSION['mensaje'] = 'Usuario y/o contraseña incorrectos';
    header('Location: inicio.php'); // Redirige de vuelta al formulario de inicio de sesión
    exit();
}
?>
