document.addEventListener('DOMContentLoaded', function() {
    // Obtener referencia a la tabla y los botones
    var tabla = document.querySelector('table');
    var editarBtn = document.getElementById('editarBtn');
    var eliminarBtn = document.getElementById('eliminarBtn');
    editarBtn.disabled = true;
    eliminarBtn.disabled = true;
    var idUnidadEdit = document.getElementById('idUnidadEdit');
    var idUnidadElim = document.getElementById('idUnidadElim');

    // Escuchar clics en la tabla
    tabla.addEventListener('click', function(e) {
        var target = e.target;

        // Verificar si el clic fue en una celda de la tabla
        if (target.tagName === 'TD') {
            // Verificar si la celda ya está seleccionada
            var yaSeleccionada = target.classList.contains('seleccionado');

            // Desseleccionar todos los elementos
            var celdas = tabla.querySelectorAll('td');
            celdas.forEach(function(celda) {
                celda.classList.remove('seleccionado');
            });

            // Marcar como seleccionado el elemento clickeado si no estaba seleccionado previamente
            if (!yaSeleccionada) {
                target.classList.add('seleccionado');
            }

            // Habilitar o deshabilitar botones según si hay una celda seleccionada
            var celdaSeleccionada = tabla.querySelector('.seleccionado');
            editarBtn.disabled = !celdaSeleccionada;
            eliminarBtn.disabled = !celdaSeleccionada;
            
            // Obtener el nombre de la unidad seleccionada y actualizar el campo en el modal de edición
            var nombreUnidad = celdaSeleccionada ? celdaSeleccionada.innerText : '';
            document.getElementById('nombreUnidadEdit').value = nombreUnidad;
            //Obtener el ID de la unidad seleccionada y actualizar el campo oculto en el formulario de edición
            var idUnidad = document.querySelector('.seleccionado').dataset.id; // Suponiendo que tengas un atributo de datos "id" en tu fila de tabla
            idUnidadEdit.value = idUnidad;
            idUnidadElim.value = idUnidad;
        }
    });
});