<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registro</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="/css/registro.css">
</head>

<body>
  <main class="container mt-5">
    <h1 class="mb-4">Formulario de Registro</h1>
    <form class="row g-3 needs-validation" novalidate action="procesar_registro.php" method="post">
      <div class="col-md-6">
        <label for="validationCustom01" class="form-label">Nombre</label>
        <input type="text" class="form-control" id="validationCustomName" name="nombre" value="" required>
        <div class="valid-feedback">
          ¡Se ve bien!
        </div>
      </div>
      <div class="col-md-6">
        <label for="validationCustom02" class="form-label">Apellido</label>
        <input type="text" class="form-control" id="validationCustomLastName" name="apellido" value="" required>
        <div class="valid-feedback">
          ¡Se ve bien!
        </div>
      </div>
      <div class="col-md-6">
        <label for="validationCustomUsername" class="form-label">Usuario</label>
        <input type="text" class="form-control" id="validationCustomUsername" name="usuario" value="" required>
        <div class="invalid-feedback">
          Por favor ingrese un usuario.
        </div>
      </div>
      <div class="col-md-6">
        <label for="validationCustomUsername" class="form-label">Contraseña</label>
        <input type="password" class="form-control" id="validationCustomPassword" name="contrasena" aria-describedby="inputGroupPrepend"
          required>
        <div class="invalid-feedback">
          Por favor ingrese una contraseña.
        </div>
      </div>
      <div class="col-md-6">
        <label for="validationCustom04" class="form-label">Email</label>
        <div class="input-group has-validation">
          <span class="input-group-text" id="inputGroupPrepend">@</span>
          <input type="email" class="form-control" id="validationCustomEmail" name="email" aria-describedby="inputGroupPrepend"
            required>
          <div class="invalid-feedback">
            Por favor ingrese un email.
          </div>
        </div>
      </div>
      <div class="col-12 mt-3">
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
          <label class="form-check-label" for="invalidCheck">
            Acepto los términos y condiciones
          </label>
          <div class="invalid-feedback">
            Debe aceptar los términos y condiciones antes de enviar.
          </div>
        </div>
      </div>
      <div class="col-12 mt-4">
        <button class="btn botonv btn-primary" type="submit" id="submitButton" disabled>Registrar</button>
      </div>
    </form>
  </main>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    const formulario = document.querySelector(".needs-validation");
    const botonEnviar = document.getElementById("submitButton");

    formulario.addEventListener("input", function () {
      // Verifica si el formulario es válido
      const formularioValido = formulario.checkValidity();

      // Habilita o deshabilita el botón según el estado del formulario
      botonEnviar.disabled = !formularioValido;
    });
  </script>
</body>

</html>