
function mostrarInfo(boton) {
        var dispositivo = boton.getAttribute('data-dispositivo');
        var hardware = boton.getAttribute('data-hardware');
        var unidad = boton.getAttribute('data-unidad');
        var descripcion = boton.getAttribute('data-descripcion');
    
        // Puedes hacer lo que necesites con estos datos, por ejemplo, actualizar el contenido del modal
        $(document).on('shown.bs.modal', '#infoModal', function () {
                actualizarContenidoModal(dispositivo, hardware, unidad, descripcion);
        });
}

function actualizarContenidoModal(dispositivo, hardware, unidad, descripcion) {
        // Aquí puedes actualizar el contenido del modal con los nuevos datos
        document.getElementById('dispositivo').innerText = 'Nombre: ' + dispositivo;
        document.getElementById('hardware').innerText = 'Hardware: ' + hardware;
        document.getElementById('unidad').innerText = 'Unidad: ' + unidad;
        document.getElementById('descripcion').innerText = 'Descripción ' + descripcion;
}


    
    