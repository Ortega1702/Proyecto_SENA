document.addEventListener('DOMContentLoaded', function() {
    //SECCION UNIDADES
        // Obtener referencia a la tabla y los botones
        var tablaUnidades = document.getElementById('tableUnidades');
        var editarUnidadBtn = document.getElementById('editarUnidadBtn');
        var eliminarUnidadBtn = document.getElementById('eliminarUnidadBtn');
        editarUnidadBtn.disabled = true;
        eliminarUnidadBtn.disabled = true;
        var idUnidadEdit = document.getElementById('idUnidadEdit');
        var idUnidadElim = document.getElementById('idUnidadElim');

        // Escuchar clics en la tabla
        tablaUnidades.addEventListener('click', function(e) {
            let target = e.target;

            // Verificar si el clic fue en una celda de la tabla
            if (target.tagName === 'TD') {
                // Verificar si la celda ya está seleccionada
                let yaSeleccionada = target.classList.contains('seleccionado');

                // Desseleccionar todos los elementos
                let celdas = tablaUnidades.querySelectorAll('td');
                celdas.forEach(function(celda) {
                    celda.classList.remove('seleccionado');
                });

                // Marcar como seleccionado el elemento clickeado si no estaba seleccionado previamente
                if (!yaSeleccionada) {
                    target.classList.add('seleccionado');
                }

                // Habilitar o deshabilitar botones según si hay una celda seleccionada
                let celdaSeleccionada = tablaUnidades.querySelector('.seleccionado');
                editarUnidadBtn.disabled = !celdaSeleccionada;
                eliminarUnidadBtn.disabled = !celdaSeleccionada;
                
                // Obtener el nombre de la unidad seleccionada y actualizar el campo en el modal de edición
                let nombreUnidad = celdaSeleccionada ? celdaSeleccionada.innerText : '';
                document.getElementById('nombreUnidadEdit').value = nombreUnidad;
                //Obtener el ID de la unidad seleccionada y actualizar el campo oculto en el formulario de edición
                let idUnidad = document.querySelector('.seleccionado').dataset.id; // Suponiendo que tengas un atributo de datos "id" en tu fila de tabla
                idUnidadEdit.value = idUnidad;
                idUnidadElim.value = idUnidad;
            }
        });

    //SECCION HARDWARE
        // Obtener referencia a la tabla y los botones
        var tablaHardware = document.getElementById('tableHardware');
        var editarHardwareBtn = document.getElementById('editarHardwareBtn');
        var eliminarHardwareBtn = document.getElementById('eliminarHardwareBtn');
        editarHardwareBtn.disabled = true;
        eliminarHardwareBtn.disabled = true;
        var idHardwareEdit = document.getElementById('idHardwareEdit');
        var idHardwareElim = document.getElementById('idHardwareElim');

        // Escuchar clics en la tabla
        tablaHardware.addEventListener('click', function(e) {
            let target = e.target;

            // Verificar si el clic fue en una celda de la tabla
            if (target.tagName === 'TD') {
                // Verificar si la celda ya está seleccionada
                let yaSeleccionada = target.classList.contains('seleccionado');

                // Desseleccionar todos los elementos
                let celdas = tablaHardware.querySelectorAll('td');
                celdas.forEach(function(celda) {
                    celda.classList.remove('seleccionado');
                });

                // Marcar como seleccionado el elemento clickeado si no estaba seleccionado previamente
                if (!yaSeleccionada) {
                    target.classList.add('seleccionado');
                }

                // Habilitar o deshabilitar botones según si hay una celda seleccionada
                let celdaSeleccionada = tablaHardware.querySelector('.seleccionado');
                editarHardwareBtn.disabled = !celdaSeleccionada;
                eliminarHardwareBtn.disabled = !celdaSeleccionada;
                
                // Obtener el nombre de la unidad seleccionada y actualizar el campo en el modal de edición
                let nombreHardware = celdaSeleccionada ? celdaSeleccionada.innerText : '';
                document.getElementById('nombreHardwareEdit').value = nombreHardware;
                //Obtener el ID de la unidad seleccionada y actualizar el campo oculto en el formulario de edición
                let idHardware = document.querySelector('.seleccionado').dataset.id; // Suponiendo que tengas un atributo de datos "id" en tu fila de tabla
                idHardwareEdit.value = idHardware;
                idHardwareElim.value = idHardware;
            }
        });
});