<?php
// Nombre del archivo CSV de ejemplo
$nombre_archivo = "formato_ejemplo.csv";

// Encabezados para forzar la descarga del archivo
header('Content-Type: application/csv');
header('Content-Disposition: attachment; filename="' . $nombre_archivo . '"');

// Abre el archivo en modo de escritura
$archivo = fopen('php://output', 'w');

// Escribe los datos en el archivo
fputcsv($archivo, array('AAAA/MM/DD HH:MM:SS', 'valor'));

// Cierra el archivo
fclose($archivo);
?>
