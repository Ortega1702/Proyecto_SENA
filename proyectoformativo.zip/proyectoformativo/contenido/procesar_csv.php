<?php
include("conexion.php");
// Verifica si se ha enviado un archivo
if (isset($_FILES['archivo_csv'])) {
    $archivo_csv = $_FILES['archivo_csv']['tmp_name'];

    // Procesa el archivo CSV y almacena los datos en la base de datos
    if (($handle = fopen($archivo_csv, "r")) !== false) {

        // Verifica la conexión
        if ($conn->connect_error) {
            die("Conexión fallida: " . $conn->connect_error);
        }

        // Obtiene el nombre de la tabla del dispositivo y el ID del usuario (ajusta según tu estructura)
        $nombre_tabla = $_POST['tabla'];
        $dispositivo = $_POST['valor'];
        $id_usuario = $_POST['id_usuario'];
        $id_dispositivo = $_POST['id_dispositivo'];

        // Lee el archivo CSV línea por línea
        while (($data = fgetcsv($handle, 1000, ",")) !== false) {
            $fecha = $data[0]; // La primera columna del CSV debe ser la fecha
            $valor = $data[1]; // La segunda columna del CSV debe ser el valor

            // Inserta los datos en la base de datos
            $sql_insert = "INSERT INTO $nombre_tabla (id_dispositivo, fecha, $dispositivo) VALUES ('$id_dispositivo', '$fecha', '$valor')";
            $conn->query($sql_insert);
        }

        // Cierra la conexión a la base de datos
        $conn->close();

        // Cierra el archivo CSV
        fclose($handle);

        // Redirige o muestra un mensaje de éxito
        header("Location: dispositivos.php");
        exit();
    } else {
        echo "Error al leer el archivo CSV";
    }
} else {
    echo "No se ha enviado ningún archivo";
}
?>
