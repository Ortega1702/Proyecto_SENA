<!DOCTYPE html>
<html lang="en">
    
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Unidades</title>
        <link rel="stylesheet" href="../css/unidades.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    </head>
    
    <body>
        <?php
            session_start();
            include('../php/header.php');

            if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
                header('Location: inicio.php'); // Si no ha iniciado sesión, redirige al formulario de inicio de sesión
                exit();
            }

            if (isset($_SESSION['mensaje'])) {
                echo "<script>alert('" . $_SESSION['mensaje'] . "')</script>";
                unset($_SESSION['mensaje']); // Elimina el mensaje de la sesión para que no se muestre de nuevo
            }
        ?>
        <div class="p-0 m-2">
            <h1>Unidades</h1>
            <table class="table">
                <tr>
                    <th>Nombre</th>
                </tr>
                <?php
                    // Tu código de conexión a la base de datos y consulta
                    require_once 'conexion.php';
    
                    $id_usuario = $_SESSION['id_usuario'];

                    // Consulta SQL para seleccionar todos los registros de la tabla "unidades"
                    $sql = "SELECT * FROM unidades WHERE id_usuario=$id_usuario";

                    // Ejecuta la consulta
                    $result = $conn->query($sql);

                    if ($result) {
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>";
                                echo "<td data-id='" . $row["id"] . "'>" . $row["nombre"] . "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='1'>Aún no tienes unidades creadas</td></tr>";
                        }
                    } else {
                        echo "Error en la consulta: " . $conn->error;
                    }

    
                    // Cierra la conexión a la base de datos cuando hayas terminado
                    $conn->close();
                ?>
            </table>
        </div>
        <div class="row p-0 m-0">
            <div class=" col-12 col-lg-6">
                <div class="buttons1">
                    <button type="button" class="btn unidad text-center" data-bs-toggle="modal"
                        data-bs-target="#exampleModal">+ Nueva unidad
                    </button>    
                </div>
            </div> 
            <div class="col-12 col-lg-6 d-flex justify-content-end">
                    <button type="button" id="editarBtn" class="btn unidad text-center" data-bs-toggle="modal"
                        data-bs-target="#modalEditar">Editar
                    </button>    
                    <button type="button" id="eliminarBtn" class="btn unidad text-center" data-bs-toggle="modal"
                        data-bs-target="#modalEliminar">Eliminar
                    </button>
            </div> 
        </div>  

        <!-- Modal de creacion -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h1 class="modal-title fs-5" id="exampleModalLabel">Nueva unidad</h1>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                  <form action="creacion_unidad.php" method="post">
                    <div class="mb-3">
                      <label for="exampleInputEmail1" class="form-label">Nombre</label>
                      <input type="text" class="form-control" name ="nombre" id="exampleInputPassword1" id="validationCustomUsername"
                        aria-describedby="inputGroupPrepend" required>
                    </div>
                    <button type="submit" class="btn botonv">Crear unidad</button>
                  </form>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn botong" data-bs-dismiss="modal">Cancelar</button>
                </div>
              </div>
            </div>
        </div>

        <!-- Modal de Edición -->
        <div class="modal fade" id="modalEditar" tabindex="-1" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Editar unidad</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="edicion_unidad.php" method="post">
                            <div class="mb-3">
                                <label for="exampleInputPassword1" class="form-label">Nombre</label>
                                <input type="hidden" name="id_unidad" id="idUnidadEdit" value="">
                                <input type="text" class="form-control" name="nombre" id="nombreUnidadEdit" required>
                            </div>
                            <button type="submit" class="btn botonv">Guardar cambios</button>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn botong" data-bs-dismiss="modal">Cancelar</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal de Eliminar -->
        <div class="modal fade" id="modalEliminar" tabindex="-1" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Eliminar unidad</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="eliminacion_unidad.php" method="post">
                            <div class="mb-3">
                                <label for="exampleInputPassword1" class="form-label">¿Estás seguro que deseas eliminar la unidad?</label>
                                <input type="hidden" name="id_unidad" id="idUnidadElim" value="">
                            </div>
                            <button type="submit" class="btn botonv">Eliminar</button>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn botong" data-bs-dismiss="modal">Cancelar</button>
                    </div>
                </div>
            </div>
        </div>

        <script src="../js/code.jquery.com_jquery-3.7.0.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="../js/unidades.js"></script>
    </body>

</html>