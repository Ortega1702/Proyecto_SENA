<!DOCTYPE html>
<html lang="en">
    
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Gestión</title>
        <link rel="stylesheet" href="../css/unidades.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    </head>
    
    <body>
        <?php
            include('../php/header.php');
            require_once 'conexion.php';

            $unidad = $_SESSION['unidad'];
            $rol = $_SESSION['rol'];

            if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
                header('Location: inicio.php'); // Si no ha iniciado sesión, redirige al formulario de inicio de sesión
                exit();
            }

            if (isset($_SESSION['mensaje'])) {
                echo "<script>alert('" . $_SESSION['mensaje'] . "')</script>";
                unset($_SESSION['mensaje']); // Elimina el mensaje de la sesión para que no se muestre de nuevo
            }
        ?>
        <div class="secciones">
            <div class="seccion-unidades">
                <div class="p-0 m-2">
                    <h2>Unidades</h2>
                    <table class="table" id="tableUnidades">
                        <tr>
                            <th>Nombre</th>
                        </tr>
                        <?php
                            // Consulta SQL para seleccionar todos los registros de la tabla "unidades"
                            $sql_unidades = "SELECT * FROM unidades";

                            // Ejecuta la consulta
                            $result_unidades = $conn->query($sql_unidades);

                            if ($result_unidades) {
                                if ($result_unidades->num_rows > 0) {
                                    while ($row = $result_unidades->fetch_assoc()) {
                                        echo "<tr>";
                                        echo "<td data-id='" . $row["id"] . "'>" . $row["nombre"] . "</td>";
                                        echo "</tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='1'>Aún no tienes unidades creadas</td></tr>";
                                }
                            } else {
                                echo "Error en la consulta: " . $conn->error;
                            }
                        ?>
                    </table>
                </div>
                <div class="row p-0 m-0">
                    <div class=" col-12 col-lg-6">
                        <div class="buttons1">
                            <button type="button" class="btn unidad text-center" data-bs-toggle="modal"
                                data-bs-target="#modalCrearUnidad">+ Nueva unidad
                            </button>    
                        </div>
                    </div> 
                    <div class="col-12 col-lg-6 d-flex justify-content-end">
                            <button type="button" id="editarUnidadBtn" class="btn unidad text-center" data-bs-toggle="modal"
                                data-bs-target="#modalEditarUnidad">Editar
                            </button>    
                            <button type="button" id="eliminarUnidadBtn" class="btn unidad text-center" data-bs-toggle="modal"
                                data-bs-target="#modalEliminarUnidad">Eliminar
                            </button>
                    </div> 
                </div>  

                <!-- Modal de creacion -->
                <div class="modal fade" id="modalCrearUnidad" tabindex="-1" aria-labelledby="exampleModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Nueva unidad</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                        <form action="creacion_unidad.php" method="post">
                            <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Nombre</label>
                            <input type="text" class="form-control" name ="nombre" id="exampleInputPassword1" id="validationCustomUsername"
                                aria-describedby="inputGroupPrepend" required>
                            </div>
                            <button type="submit" class="btn botonv">Crear unidad</button>
                        </form>
                        </div>
                        <div class="modal-footer">
                        <button type="button" class="btn botong" data-bs-dismiss="modal">Cancelar</button>
                        </div>
                    </div>
                    </div>
                </div>

                <!-- Modal de Edición -->
                <div class="modal fade" id="modalEditarUnidad" tabindex="-1" aria-labelledby="exampleModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="exampleModalLabel">Editar unidad</h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form action="edicion_unidad.php" method="post">
                                    <div class="mb-3">
                                        <label for="exampleInputPassword1" class="form-label">Nombre</label>
                                        <input type="hidden" name="id_unidad" id="idUnidadEdit" value="">
                                        <input type="text" class="form-control" name="nombre" id="nombreUnidadEdit" required>
                                    </div>
                                    <button type="submit" class="btn botonv">Guardar cambios</button>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn botong" data-bs-dismiss="modal">Cancelar</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Modal de Eliminar -->
                <div class="modal fade" id="modalEliminarUnidad" tabindex="-1" aria-labelledby="exampleModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="exampleModalLabel">Eliminar unidad</h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form action="eliminacion_unidad.php" method="post">
                                    <div class="mb-3">
                                        <label for="exampleInputPassword1" class="form-label">¿Estás seguro que deseas eliminar la unidad?</label>
                                        <input type="hidden" name="id_unidad" id="idUnidadElim" value="">
                                    </div>
                                    <button type="submit" class="btn botonv">Eliminar</button>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn botong" data-bs-dismiss="modal">Cancelar</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <hr>
            <br>
            <div class="seccion-hardware">
                <div class="p-0 m-2">
                    <h2>Hardware</h2>
                    <table class="table" id="tableHardware">
                        <tr>
                            <th>Nombre</th>
                        </tr>
                        <?php
                            // Consulta SQL para seleccionar todos los registros de la tabla "unidades"
                            $sql_hardware = "SELECT * FROM hardware";
                            

                            // Ejecuta la consulta
                            $result_hardware = $conn->query($sql_hardware);

                            if ($result_hardware) {
                                if ($result_hardware->num_rows > 0) {
                                    while ($row = $result_hardware->fetch_assoc()) {
                                        echo "<tr>";
                                        echo "<td data-id='" . $row["id"] . "'>" . $row["nombre"] . "</td>";
                                        echo "</tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='1'>Aún no tienes hardware disponibles</td></tr>";
                                }
                            } else {
                                echo "Error en la consulta: " . $conn->error;
                            }

            
                            // Cierra la conexión a la base de datos cuando hayas terminado
                            $conn->close();
                        ?>
                    </table>
                </div>
                <div class="row p-0 m-0">
                    <div class=" col-12 col-lg-6">
                        <div class="buttons1">
                            <button type="button" class="btn unidad text-center" data-bs-toggle="modal"
                                data-bs-target="#modalCrearHardware">+ Nuevo Hardware
                            </button>    
                        </div>
                    </div> 
                    <div class="col-12 col-lg-6 d-flex justify-content-end">
                            <button type="button" id="editarHardwareBtn" class="btn unidad text-center" data-bs-toggle="modal"
                                data-bs-target="#modalEditarHardware">Editar
                            </button>    
                            <button type="button" id="eliminarHardwareBtn" class="btn unidad text-center" data-bs-toggle="modal"
                                data-bs-target="#modalEliminarHardware">Eliminar
                            </button>
                    </div> 
                </div>  

                <!-- Modal de creacion -->
                <div class="modal fade" id="modalCrearHardware" tabindex="-1" aria-labelledby="exampleModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Nuevo Hardware</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                        <form action="creacion_hardware.php" method="post">
                            <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Nombre</label>
                            <input type="text" class="form-control" name ="nombre" id="exampleInputPassword1" id="validationCustomUsername"
                                aria-describedby="inputGroupPrepend" required>
                            </div>
                            <button type="submit" class="btn botonv">Crear Hardware</button>
                        </form>
                        </div>
                        <div class="modal-footer">
                        <button type="button" class="btn botong" data-bs-dismiss="modal">Cancelar</button>
                        </div>
                    </div>
                    </div>
                </div>

                <!-- Modal de Edición -->
                <div class="modal fade" id="modalEditarHardware" tabindex="-1" aria-labelledby="exampleModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="exampleModalLabel">Editar hardware</h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form action="edicion_hardware.php" method="post">
                                    <div class="mb-3">
                                        <label for="exampleInputPassword1" class="form-label">Nombre</label>
                                        <input type="hidden" name="id_hardware" id="idHardwareEdit" value="">
                                        <input type="text" class="form-control" name="nombre" id="nombreHardwareEdit" required>
                                    </div>
                                    <button type="submit" class="btn botonv">Guardar cambios</button>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn botong" data-bs-dismiss="modal">Cancelar</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Modal de Eliminar -->
                <div class="modal fade" id="modalEliminarHardware" tabindex="-1" aria-labelledby="exampleModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="exampleModalLabel">Eliminar hardware</h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form action="eliminacion_hardware.php" method="post">
                                    <div class="mb-3">
                                        <label for="exampleInputPassword1" class="form-label">¿Estás seguro que deseas eliminar el hardware?</label>
                                        <input type="hidden" name="id_hardware" id="idHardwareElim" value="">
                                    </div>
                                    <button type="submit" class="btn botonv">Eliminar</button>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn botong" data-bs-dismiss="modal">Cancelar</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script src="../js/code.jquery.com_jquery-3.7.0.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="../js/unidades.js"></script>
    </body>

</html>