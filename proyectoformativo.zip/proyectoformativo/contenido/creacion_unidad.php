<?php
session_start();
// Incluir el archivo de conexión a la base de datos
require_once 'conexion.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Obtener los datos del formulario
$nombre = $_POST['nombre'];
$id_usuario = $_SESSION['id_usuario'];

// Insertar el nuevo usuario en la base de datos
$sql = "INSERT INTO unidades (nombre, id_usuario) VALUES ('$nombre', '$id_usuario')";

if ($conn->query($sql) === TRUE) {
    echo 'Unidad creada con éxito';
    header("Location: unidades.php");
    exit();
} else {
    echo "<script>alert('Error al crear unidad')</script>";
}

// Cerrar la conexión a la base de datos
$conn->close();
?>
