<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dispositivos</title>
  <link rel="stylesheet" href="../css/dispositivos.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
</head>

<body>
  <?php 
    session_start();
    include('../php/header.php');
    require_once('conexion.php');

    $id_usuario = $_SESSION['id_usuario'];

    // Consulta SQL para seleccionar todos los registros de la tabla "unidades"
    $sql_unidades = "SELECT id, nombre FROM unidades WHERE id_usuario=$id_usuario";

    // Ejecuta la consulta
    $result_unidades = $conn->query($sql_unidades);

    // Verificar si hay resultados
    if ($result_unidades->num_rows > 0) {
      // Inicializar un array para almacenar los nombres de las unidades
      $unidades = array();

      // Obtener los nombres de las unidades
      while($row = $result_unidades->fetch_assoc()) {
        $unidades[] = array(
          'id' => $row["id"],
          'nombre' => $row["nombre"]
        );
      }
    } else {
      echo "No se encontraron unidades";
    }


    // Consulta SQL para obtener los datos de los dispositivos
    $sql_dispositivos = "SELECT id, nombre, hardware, id_unidad, descripcion FROM dispositivos WHERE id_usuario=$id_usuario";

    // Ejecuta la consulta
    $result_dispositivos = $conn->query($sql_dispositivos);

    // Verificar si hay resultados
    if ($result_dispositivos->num_rows > 0) {
      $dispositivos = array(); // Inicializar un array para almacenar los datos de los dispositivos

      while($row = $result_dispositivos->fetch_assoc()) {
        $dispositivos[] = $row; // Agregar cada fila como un elemento al array de dispositivos
      }
    } else {
      echo "No se encontraron dispositivos";
    }

    // Cerrar la conexión
    $conn->close();
  ?>

  <div class="fondo">
    <!-- lado izquierdo -->
    <div class=" m-2 lista">
      <label for="exampleInputEmail1" class="form-label fw-bold fs-5">Selecciona una unidad</label>
      <select class="form-select" id="validationCustom04" name="hardware" required>
        <option selected disabled value="">Escoger...</option>
        <?php 
          foreach($unidades as $unidad) {
            echo "<option value='" . $unidad['id'] . "'>$unidad[nombre]</option>";
          }
        ?>
      </select>

    </div>
    <!-- lado derecho -->
    <div class="d-flex flex-row justify-content-between espacio">
      <h4>Mis dispositivos</h4>
      <div>
        <button type="button" class="btn plantilla text-center" data-bs-toggle="modal" data-bs-target="#exampleModal">+ Nuevo dispositivo
        </button>
        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Nuevo dispositivo</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <form action="creacion_dispositivo.php" method="post">
                  <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Nombre</label>
                    <input type="text" class="form-control" name="nombre" id="exampleInputPassword1" id="validationCustomUsername" aria-describedby="inputGroupPrepend" required>
                  </div>
                  <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Hardware</label>
                    <select class="form-select" id="validationCustom04" name="hardware" required>
                      <option selected disabled value="">Escoger...</option>
                      <option>Arduino</option>
                      <option>ESP32</option>
                      <option>ESP8266</option>
                      <option>Raspberry Pi</option>
                      <option>Other</option>
                    </select>
                  </div>
                  <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Unidad</label>
                    <select class="form-select" name="unidades_listbox" id="unidades_listbox" name="unidad" required>
                      <option selected disabled value="">Escoger...</option>
                      <?php 
                        foreach($unidades as $unidad) {
                          echo "<option value='" . $unidad['id'] . "'>$unidad[nombre]</option>";
                        }
                      ?>
                    </select>
                  </div>
                  <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Descripción</label>
                    <textarea class="form-control" id="exampleFormControlTextarea1" name="descripcion" rows="5" placeholder="Descripción" minlength="4" maxlength="128"></textarea>
                  </div>
                  <button type="submit" class="btn botonv">Crear dispositivo</button>
                </form>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn botong" data-bs-dismiss="modal">Cancelar</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="cards-dispositivos row">
    <?php
      foreach ($dispositivos as $dispositivo) {
          echo '<div class="card text-center m-3" style="width: 15rem;">';
          echo '<div class="card-header bg-transparent border-success">';
          echo '<h5 class="card-title">' . $dispositivo['nombre'] . '</h5>';
          echo '</div>';
          echo '<div class="card-body">';
          echo '<p>' . $dispositivo['hardware'] . '</p>';
          echo '<p>' . $dispositivo['descripcion'] . '</p>';
          echo '</div>';
          echo '<div class="card-footer bg-transparent border-success">';
          echo '<button type="button" class="btn plantilla text-center m-3" data-toggle="modal" data-target="#modalUbicacion' . $dispositivo['id'] . '">Ubicacion</button>';
          echo '</div>';
          echo '</div>';
      }
    ?>
    </div>
  </div>
  </div>
  </div>
  </div>
  </div>
  </div>

  <script src="../js/code.jquery.com_jquery-3.7.0.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>