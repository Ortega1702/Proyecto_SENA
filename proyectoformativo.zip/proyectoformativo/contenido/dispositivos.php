<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dispositivos</title>
  <link rel="stylesheet" href="../css/dispositivos.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
</head>

<body>
  <?php
  session_start();
  include('../php/header.php');
  require_once('conexion.php');

  $id_usuario = $_SESSION['id_usuario'];

  // Consulta SQL para seleccionar todos los registros de la tabla "unidades"
  $sql_unidades = "SELECT id, nombre FROM unidades WHERE id_usuario=$id_usuario";

  // Ejecuta la consulta
  $result_unidades = $conn->query($sql_unidades);

  // Verificar si hay resultados
  if ($result_unidades->num_rows > 0) {
    // Inicializar un array para almacenar los nombres de las unidades
    $unidades = array();

    // Obtener los nombres de las unidades
    while ($row = $result_unidades->fetch_assoc()) {
      $unidades[] = array(
        'id' => $row["id"],
        'nombre' => $row["nombre"]
      );
    }
  } 

  // Consulta SQL para obtener los datos de los dispositivos
  $sql_dispositivos = "SELECT dispositivos.id, dispositivos.nombre AS dispositivo, hardware, id_unidad, descripcion, unidades.nombre AS unidad FROM dispositivos INNER JOIN unidades ON unidades.id=dispositivos.id_unidad WHERE dispositivos.id_usuario=$id_usuario ORDER BY unidad";

  // Ejecuta la consulta
  $result_dispositivos = $conn->query($sql_dispositivos);

  // Verificar si hay resultados
  if ($result_dispositivos->num_rows > 0) {
    $dispositivos = array(); // Inicializar un array para almacenar los datos de los dispositivos

    while ($row = $result_dispositivos->fetch_assoc()) {
      $dispositivos[] = $row; // Agregar cada fila como un elemento al array de dispositivos
    }
  } 

  ?>

  <div class="fondo">
    <!-- lado derecho -->
    <div class="d-flex flex-row justify-content-between espacio">
      <h2 class="fw-bold">Mis dispositivos</h2>
      <div>
        <button type="button" class="btn plantilla text-center" data-bs-toggle="modal" data-bs-target="#exampleModal">+ Nuevo dispositivo
        </button>
        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Nuevo dispositivo</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <form action="creacion_dispositivo.php" method="post">
                  <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Nombre</label>
                    <input type="text" class="form-control" name="nombre" id="exampleInputPassword1" id="validationCustomUsername" aria-describedby="inputGroupPrepend" required>
                  </div>
                  <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Hardware</label>
                    <select class="form-select" id="validationCustom04" name="hardware" required>
                      <option selected disabled value="">Escoger...</option>
                      <option>Arduino</option>
                      <option>ESP32</option>
                      <option>ESP8266</option>
                      <option>Raspberry Pi</option>
                      <option>Other</option>
                    </select>
                  </div>
                  <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Unidad</label>
                    <select class="form-select" name="unidades_listbox" id="unidades_listbox" required>
                      <option selected disabled value="">Escoger...</option>
                      <?php
                      foreach ($unidades as $unidad) {
                        echo "<option value='" . $unidad['id'] . "'>$unidad[nombre]</option>";
                      }
                      ?>
                    </select>
                  </div>
                  <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Descripción</label>
                    <textarea class="form-control" id="exampleFormControlTextarea1" name="descripcion" rows="5" placeholder="Descripción" minlength="4" maxlength="128"></textarea>
                  </div>
                  <button type="submit" class="btn botonv">Crear dispositivo</button>
                </form>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn botong" data-bs-dismiss="modal">Cancelar</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="cards-dispositivos row w-100">
      <?php
      $jsonData = file_get_contents("php://input");
      $data = json_decode($jsonData, true);

      // Verifica si los índices están presentes antes de intentar acceder a ellos
      $dispositivo_json = isset($data['dispositivo']) ? $data['dispositivo'] : null;
      $hardware_json = isset($data['hardware']) ? $data['hardware'] : null;
      $unidad_json = isset($data['unidad']) ? $data['unidad'] : null;
      $descripcion_json = isset($data['descripcion']) ? $data['descripcion'] : null;
      
      if($result_unidades->num_rows > 0) {
        foreach ($unidades as $unidad) {
          echo '<h3>' . $unidad['nombre'] . '</h3>';
          if($result_dispositivos->num_rows > 0) {
            foreach ($dispositivos as $dispositivo) {
              if ($dispositivo['id_unidad'] == $unidad['id']) {
                echo '<div class="card text-center m-3" style="width: 15rem;">';
                echo '<div class="card-header bg-transparent border-success">';
                echo '<h5 class="card-title">' . $dispositivo['dispositivo'] . '</h5>';
                echo '</div>';
                echo '<div class="card-body">';
                echo '<p>' . $dispositivo['hardware'] . '</p>';
                echo '<p>' . $dispositivo['unidad'] . '</p>';
                echo '<p>' . $dispositivo['descripcion'] . '</p>';
                echo '</div>';
                echo '<div class="card-footer bg-transparent border-success">';
                echo '<button type="button" class="btn plantilla text-center" 
                  data-bs-toggle="modal" 
                  data-bs-target="#modal' . $dispositivo['dispositivo'] .'">
                  Info
                </button>';
                echo '</div>';
                echo '</div>';
                echo '<!-- Modal de info -->
                      <div class="modal fade" id="modal' . $dispositivo['dispositivo'] .'" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                          <div class="modal-dialog modal-xl">
                              <div class="modal-content">
                              <div class="modal-header">
                                <h1 class="modal-title fs-5" id="exampleModalLabel">DATOS</h1>
                                <button
                                  type="button"
                                  class="btn-close"
                                  data-bs-dismiss="modal"
                                  aria-label="Close"
                                ></button>
                              </div>
                              <div class="row">
                              <div class="col-12 col-lg-6">
                                <div class="modal-body">
                                  <p id="dispositivo">' . $dispositivo['dispositivo'] .'</p>
                                  <p id="hardware">' . $dispositivo['hardware'] .'</p>
                                  <p id="unidad">' . $dispositivo['unidad'] .'</p>
                                  <p id="descripcion">' . $dispositivo['descripcion'] .'</p>

                                </div>
                              </div>
                              <div class="col-12 col-lg-6">
                                <canvas id="Grafica' . $dispositivo['dispositivo'] . $id_usuario . '" style="max-width: 400px; max-height: 300px;"></canvas>
                                <br>
                                <br>
                                <div class="archivo_csv">
                                  <h4>Cargar datos</h4>
                                  <form action="procesar_csv.php" method="post" enctype="multipart/form-data">
                                      <label for="archivo_csv">Selecciona un archivo CSV:</label>
                                      <input type="file" name="archivo_csv" id="archivo_csv" accept=".csv" required>
                                      <button type="submit" name="submit">Subir CSV</button>
                                      <input type="hidden" name="tabla" value="' . $dispositivo['dispositivo'] . $id_usuario . '">
                                      <input type="hidden" name="valor" value="' . $dispositivo['dispositivo'] . '">
                                      <input type="hidden" name="id_dispositivo" value="' . $dispositivo['id'] . '">
                                      <input type="hidden" name="id_usuario" value="' . $id_usuario . '">
                                      <br>
                                      <br>
                                      <p>O, si prefieres, descarga el formato de archivo CSV:</p>
                                      <a href="descargar_formato.php">Descargar Formato CSV</a>
                                  </form>
                                </div>
                                <br>
                                <br>
                                <div class="descargar_datos">
                                  <h4>Descargar datos</h4>
                                  <form action="descargar_datos_grafica.php" method="post" enctype="multipart/form-data">
                                    <label>Selecciona un rango de fechas</label>
                                    <input type="date" name="fecha_desde">
                                    <input type="date" name="fecha_hasta">
                                    <input type="hidden" name="nombre_tabla" value="' . $dispositivo['dispositivo'] . $id_usuario . '">
                                    <input type="hidden" name="dispositivo" value="' . $dispositivo['dispositivo'] . '">
                                    <input type="hidden" name="id_usuario" value="' . $id_usuario . '">
                                    <input type="submit" value="Descargar">
                                  </form>
                                </div>
                              </div>
                            </div>
                                  <div class="modal-footer">
                                      <button type="button" class="btn botong" data-bs-dismiss="modal">Cancelar</button>
                                  </div>
                              </div>
                          </div>
                      </div>';
                      
                      // Consulta para obtener los datos (ejemplo)
                      $sql_datos = "SELECT fecha, " . $dispositivo['dispositivo']. " FROM " . $dispositivo['dispositivo'] . $id_usuario;
                      $result_datos = $conn->query($sql_datos);

                      // Crear un array con los datos
                      $data = [];
                      if ($result_datos->num_rows > 0) {
                          while ($row = $result_datos->fetch_assoc()) {
                              $data[$row["fecha"]] = $row[$dispositivo['dispositivo']];
                          }
                      } 

                      echo '<script src="https://cdn.jsdelivr.net/npm/chart.js@3.7.0/dist/chart.min.js"></script>
                            <script>
                                var ctx = document.getElementById("Grafica' . $dispositivo['dispositivo'] . $id_usuario . '").getContext("2d");

                                var data = ' . json_encode($data) . '; // Datos obtenidos de la base de datos
                                var labels = Object.keys(data);
                                var values = Object.values(data);

                                var myChart = new Chart(ctx, {
                                    type: "line",
                                    data: {
                                        labels: labels,
                                        datasets: [{
                                            label: "' . $dispositivo['dispositivo'] . '",
                                            data: values,
                                            backgroundColor: "rgba(75, 192, 192, 0.2)",
                                            borderColor: "rgba(75, 192, 192, 1)",
                                            borderWidth: 1
                                        }]
                                    },
                                    options: {
                                        scales: {
                                            y: {
                                                beginAtZero: true
                                            }
                                        },
                                        maintainAspectRatio: false
                                    }
                                });
                            </script>';
              }
            }
          } else{
            echo '<p>Aún no has agregado dispositivos a esta unidad</p>';
          }
          echo '<div class="card text-center m-3" style="width: 15rem;">';
          echo '<div class="card-header bg-transparent border-success">';
          echo '<h5 class="card-title">Agregar Dispositivo</h5>';
          echo '</div>';
          echo '<div class="card-body">';
          echo '</div>';
          echo '<div class="card-footer bg-transparent border-success">';
          echo '<button type="button" class="btn plantilla text-center" data-bs-toggle="modal" data-bs-target="#exampleModal">Agregar
          </button>';
          echo '</div>';
          echo '</div>';
        }
      } else {
        echo "<h3>No se encontraron unidades</h3>";
      }
      
      // Cerrar la conexión
      $conn->close();
      ?>
    </div>
  </div>
  <script src="../js/dispositivos.js"></script>
  <script src="../js/code.jquery.com_jquery-3.7.0.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>