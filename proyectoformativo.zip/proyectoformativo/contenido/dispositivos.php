<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dispositivos</title>
  <link rel="stylesheet" href="../css/dispositivos.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
</head>

<body>
  <?php
  include('../php/header.php');
  require_once('conexion.php');

  if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: inicio.php'); // Si no ha iniciado sesión, redirige al formulario de inicio de sesión
    exit();
  }

  if (isset($_SESSION['mensaje'])) {
    echo "<script>alert('" . $_SESSION['mensaje'] . "')</script>";
    unset($_SESSION['mensaje']); // Elimina el mensaje de la sesión para que no se muestre de nuevo
  }

  $id_usuario = $_SESSION['id_usuario'];
  $rol_usuario = $_SESSION['rol'];
  $unidad_usuario = $_SESSION['unidad'];

  //CONSULTA UNIDADES
    if($rol === 'usuario'){
      // Consulta SQL para seleccionar los registros de la unidad respectiva de la tabla "unidades"
      $sql_unidades = "SELECT id, nombre FROM unidades WHERE nombre='$unidad_usuario'";
    } else {
      // Consulta SQL para seleccionar todos los registros de la tabla "unidades"
      $sql_unidades = "SELECT id, nombre FROM unidades";
    }

    // Ejecuta la consulta
    $result_unidades = $conn->query($sql_unidades);

    // Verificar si hay resultados
    if ($result_unidades->num_rows > 0) {
      // Inicializar un array para almacenar los nombres de las unidades
      $unidades = array();

      // Obtener los nombres de las unidades
      while ($row = $result_unidades->fetch_assoc()) {
        $unidades[] = array(
          'id' => $row["id"],
          'nombre' => $row["nombre"]
        );
      }
    } 

  //CONSULTA HARDWARE
    // Consulta SQL para seleccionar todos los registros de la tabla "hardware"
    $sql_hardware = "SELECT id, nombre FROM hardware";
    

    // Ejecuta la consulta
    $result_hardware = $conn->query($sql_hardware);

    // Verificar si hay resultados
    if ($result_hardware->num_rows > 0) {
      // Inicializar un array para almacenar los nombres de los hardware
      $hardware = array();

      // Obtener los nombres de los hardware
      while ($row = $result_hardware->fetch_assoc()) {
        $hardware[] = array(
          'nombre' => $row["nombre"]
        );
      }
    } 

  //CONSULTA DISPOSITIVOS
    if($rol === 'usuario'){
      // Consulta SQL para obtener los datos de los dispositivos
      $sql_dispositivos = "SELECT dispositivos.id AS id_dispositivo, dispositivos.nombre AS dispositivo, unidad_de_medida, hardware, id_unidad, descripcion, unidades.nombre AS unidad, CONCAT(usuarios.nombre, ' ', usuarios.apellido) AS nombre_usuario FROM dispositivos INNER JOIN unidades ON unidades.id=dispositivos.id_unidad INNER JOIN usuarios ON usuarios.id=dispositivos.id_usuario WHERE unidades.nombre='$unidad_usuario' ORDER BY unidades.nombre;";
    } else {
      // Consulta SQL para obtener los datos de los dispositivos
      $sql_dispositivos = "SELECT dispositivos.id AS id_dispositivo, dispositivos.nombre AS dispositivo, unidad_de_medida, hardware, id_unidad, descripcion, unidades.nombre AS unidad, CONCAT(usuarios.nombre, ' ', usuarios.apellido) AS nombre_usuario FROM dispositivos INNER JOIN unidades ON unidades.id=dispositivos.id_unidad INNER JOIN usuarios ON usuarios.id=dispositivos.id_usuario ORDER BY unidad;";
    }

    // Ejecuta la consulta
    $result_dispositivos = $conn->query($sql_dispositivos);

    // Verificar si hay resultados
    if ($result_dispositivos->num_rows > 0) {
      $dispositivos = array(); // Inicializar un array para almacenar los datos de los dispositivos

      while ($row = $result_dispositivos->fetch_assoc()) {
        $dispositivos[] = $row; // Agregar cada fila como un elemento al array de dispositivos
      }
    } 
  ?>

  <div class="fondo">
    <!-- lado derecho -->
    <div class="d-flex flex-row justify-content-between espacio">
      <h2 class="fw-bold">Mis dispositivos</h2>
      <div>
        <button type="button" class="btn plantilla text-center" data-bs-toggle="modal" data-bs-target="#exampleModal">+ Nuevo dispositivo
        </button>
        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Nuevo dispositivo</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <form action="creacion_dispositivo.php" method="post">
                  <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Nombre</label>
                    <input type="text" class="form-control" name="nombre" id="exampleInputPassword1" id="validationCustomUsername" aria-describedby="inputGroupPrepend" required>
                  </div>
                  <div class="mb-3">
                    <label for="unidad_de_medida">Unidad de Medida:</label>
                    <select class="form-select" id="unidad_de_medida" name="unidad_de_medida" onchange="mostrarOcultarCampoTexto()">
                      <option selected disabled value="">Escoger...</option>
                      <option value="Celsius">Grados Celsius (°C)</option>
                      <option value="Fahrenheit">Grados Fahrenheit (°F)</option>
                      <option value="Kelvin">Kelvin (K)</option>
                      <option value="Pascal">Pascal (Pa)</option>
                      <option value="Bar">Bar (bar)</option>
                      <option value="Atm">Atmósferas (atm)</option>
                      <option value="mmHg">Milímetros de mercurio (mmHg)</option>
                      <option value="Psi">Libras por pulgada cuadrada (psi)</option>
                      <option value="Porcentaje">Porcentaje (%)</option>
                      <option value="Lux">Lux (lx)</option>
                      <option value="m/s">Metros por segundo (m/s)</option>
                      <option value="km/h">Kilómetros por hora (km/h)</option>
                      <option value="mph">Millas por hora (mph)</option>
                      <option value="m/s2">Metros por segundo cuadrado (m/s²)</option>
                      <option value="g">Gravedad terrestre (g)</option>
                      <option value="Metros">Metros (m)</option>
                      <option value="cm">Centímetros (cm)</option>
                      <option value="mm">Milímetros (mm)</option>
                      <option value="in">Pulgadas (in)</option>
                      <option value="g">Gramos (g)</option>
                      <option value="kg">Kilogramos (kg)</option>
                      <option value="lb">Libras (lb)</option>
                      <option value="s">Segundos (s)</option>
                      <option value="ms">Milisegundos (ms)</option>
                      <option value="µs">Microsegundos (µs)</option>
                      <option value="min">Minutos (min)</option>
                      <option value="h">Horas (h)</option>
                      <option value="°">Grados (°)</option>
                      <option value="rad">Radianes (rad)</option>
                      <option value="Otra">Otra</option>
                    </select>
                    <input type="text" class="form-control mt-3" id="otraUnidad" name="unidad_de_medida" placeholder="Otra Unidad de medida" style="display: none;" disabled>
                  </div>
                  <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Hardware</label>
                    <select class="form-select" id="validationCustom04" name="hardware" required>
                      <option selected disabled value="">Escoger...</option>
                      <?php
                        foreach ($hardware as $hardware) {
                          echo "<option value='" . $hardware['nombre'] . "'>$hardware[nombre]</option>";
                        }
                      ?>
                    </select>
                  </div>
                  <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Unidad</label>
                    <select class="form-select" name="unidades_listbox" id="unidades_listbox" required>
                      <option selected disabled value="">Escoger...</option>
                      <?php
                      foreach ($unidades as $unidad) {
                        echo "<option value='" . $unidad['id'] . "'>$unidad[nombre]</option>";
                      }
                      ?>
                    </select>
                  </div>
                  <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Descripción</label>
                    <textarea class="form-control" id="exampleFormControlTextarea1" name="descripcion" rows="5" placeholder="Descripción" minlength="4" maxlength="128"></textarea>
                  </div>
                  <button type="submit" class="btn botonv">Crear dispositivo</button>
                </form>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn botong" data-bs-dismiss="modal">Cancelar</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="cards-dispositivos row w-100">
      <?php
      $jsonData = file_get_contents("php://input");
      $data = json_decode($jsonData, true);

      // Verifica si los índices están presentes antes de intentar acceder a ellos
      $dispositivo_json = isset($data['dispositivo']) ? $data['dispositivo'] : null;
      $unidad_medida_json = isset($data['unidad_de_medida']) ? $data['unidad_de_medida'] : null;
      $hardware_json = isset($data['hardware']) ? $data['hardware'] : null;
      $unidad_json = isset($data['unidad']) ? $data['unidad'] : null;
      $descripcion_json = isset($data['descripcion']) ? $data['descripcion'] : null;
      $nombre_usuario_json = isset($data['nombre_usuario']) ? $data['nombre_usuario'] : null;
      
      echo '<script src="https://cdn.jsdelivr.net/npm/chart.js@3.7.0/dist/chart.min.js"></script>';  
      
      // Inicializar un array para almacenar las instancias de Chart.js
      echo '<script>
      var charts = {};
      </script>';

      if($result_unidades->num_rows > 0) {
        foreach ($unidades as $unidad) {
          echo '<h3>' . $unidad['nombre'] . '</h3>';
          if($result_dispositivos->num_rows > 0) {
            foreach ($dispositivos as $dispositivo) {
              if ($dispositivo['id_unidad'] == $unidad['id']) {

                // Crea un identificador único para cada gráfico
                $chartId = $dispositivo['dispositivo'] . $unidad['id'];

                echo '<div class="card text-center m-3" style="width: 15rem;">';
                echo '<div class="card-header bg-transparent border-success">';
                echo '<h5 style="display: inline; margin: auto" class="card-title">' . $dispositivo['dispositivo'] . '</h5>';
                echo '<button id="eliminarDispositivo" style="border: none" data-bs-toggle="modal"
                data-bs-target="#modalEliminar' . $chartId .'"><img src="../images/x.png" width="24px"></button>';
                echo '</div>';
                echo '<div class="card-body">';
                echo '<p>' . $dispositivo['hardware'] . '</p>';
                echo '<p>' . $dispositivo['unidad'] . '</p>';
                echo '<p>' . $dispositivo['descripcion'] . '</p>';
                echo '</div>';
                echo '<div class="card-footer bg-transparent border-success">';
                echo '<button type="button" class="btn plantilla text-center" 
                  data-bs-toggle="modal" 
                  data-bs-target="#modal' . $chartId .'">
                  Info
                </button>';
                echo '</div>';
                echo '</div>';
                echo '<!-- Modal de info -->
                      <div class="modal fade" id="modal' . $chartId .'" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                          <div class="modal-dialog modal-xl">
                              <div class="modal-content">
                              <div class="modal-header">
                                <h1 class="modal-title fs-5" id="exampleModalLabel">DATOS</h1>
                                <button
                                  type="button"
                                  class="btn-close"
                                  data-bs-dismiss="modal"
                                  aria-label="Close"
                                ></button>
                              </div>
                              <div class="row">
                              <div class="col-12 col-lg-6">
                                <div class="modal-body">
                                  <p>Nombre: </p>
                                  <label id="dispositivo">' . $dispositivo['dispositivo'] .'</label>
                                  <hr width="50%">
                                  <p>Hardware: </p>
                                  <label id="hardware">' . $dispositivo['hardware'] .'</label>
                                  <hr width="50%">
                                  <p>Unidad: </p>
                                  <label id="unidad">' . $dispositivo['unidad'] .'</label>
                                  <hr width="50%">
                                  <p>Descripción: </p>
                                  <label id="descripcion">' . $dispositivo['descripcion'] .'</label>
                                  <hr width="50%">
                                  <p>Usuario creador: </p>
                                  <label id="nombre_usuario">' . $dispositivo['nombre_usuario'] .'</label>
                                  <hr width="100%">
                                </div>
                                <div class="tipo_grafica">
                                  <h6>Selecciona el tipo de Gráfica: </h6>
                                  <select class="bara" id="tipoGrafica' . $chartId . '" onchange="actualizarTipoGrafica(\'' . $chartId . '\')">
                                    <option value="line">Línea</option>
                                    <option value="bar">Barra</option>
                                  </select>
                                </div>
                                <div class="rango_fechas">
                                <h6>Selecciona el rango de fechas: </h6>
                                  <label for="start-date' . $chartId . '">Fecha de inicio:</label>
                                  <input class="fecha m-3" type="date" id="start-date' . $chartId . '">
                                  <br>
                                  <label for="end-date' . $chartId . '">Fecha de fin:</label>
                                  <input class="fecha" type="date" id="end-date' . $chartId . '">
                                  <br>
                                  <button class="fecha1 m-3" onclick="actualizarDatosGrafica(\'' . $chartId . '\')">Filtrar Fechas</button>
                                </div>
                              </div>
                              <div class="col-12 col-lg-6">
                                <h3>Gráfica de datos</h3>
                                <canvas id="Grafica' . $chartId . '" style="max-width: 400px; max-height: 300px; border: 5px solid #39a900; border-radius: 10px; margin: 15px 50px"></canvas>
                                <br>
                                <hr>
                                <div class="archivo_csv">
                                  <h4>Cargar datos</h4>
                                  <form action="procesar_csv.php" method="post" enctype="multipart/form-data">
                                      <label class="m-2" for="archivo_csv">Selecciona un archivo CSV:</label>
                                      <input class="m-2" type="file" name="archivo_csv" id="archivo_csv" accept=".csv" required>
                                      <button class="archivo m-2" type="submit" name="submit">Subir CSV</button>
                                      <input type="hidden" name="tabla" value="' . $chartId . '">
                                      <input type="hidden" name="valor" value="' . $dispositivo['dispositivo'] . '">
                                      <input type="hidden" name="id_dispositivo" value="' . $dispositivo['id_dispositivo'] . '">
                                      <input type="hidden" name="id_usuario" value="' . $id_usuario . '">
                                      <br>
                                      <br>
                                      <p>O, si prefieres, descarga el formato de archivo CSV:</p>
                                      <a href="descargar_formato.php">Descargar Formato CSV</a>
                                      <label>(Te recomendamos abrirlo con el bloc de notas)</label>
                                  </form>
                                </div>
                                <br>
                                <hr>
                                <div class="descargar_datos">
                                  <h4>Descargar datos</h4>
                                  <form action="descargar_datos_grafica.php" method="post" enctype="multipart/form-data">
                                    <label>Selecciona un rango de fechas</label>
                                    <input class="descargar m-2" type="date" name="fecha_desde">
                                    <input class="descargar m-2" type="date" name="fecha_hasta">
                                    <input type="hidden" name="nombre_tabla" value="' . $chartId . '">
                                    <input type="hidden" name="dispositivo" value="' . $dispositivo['dispositivo'] . '">
                                    <input type="hidden" name="id_usuario" value="' . $id_usuario . '">
                                    <input class="descargar1 m-2" type="submit" value="Descargar">
                                  </form>
                                </div>
                              </div>
                            </div>
                                  <div class="modal-footer">
                                      <button type="button" class="btn botong" data-bs-dismiss="modal">Cancelar</button>
                                  </div>
                              </div>
                          </div>
                      </div>';
                      
                      // Consulta para obtener los datos (ejemplo)
                      $sql_datos = "SELECT fecha, " . $dispositivo['dispositivo']. " FROM " . $dispositivo['dispositivo'] . $unidad['id'] . " ORDER BY fecha";
                      $result_datos = $conn->query($sql_datos);

                      // Crear un array con los datos
                      $datos_grafica = [];
                      if ($result_datos->num_rows > 0) {
                          while ($row = $result_datos->fetch_assoc()) {
                              $datos_grafica[$row["fecha"]] = $row[$dispositivo['dispositivo']];
                          }
                      } 

                      // Inicializa el gráfico para este dispositivo
                    echo '<script>
                        charts["' . $chartId . '"] = inicializarGrafico("' . $chartId . '");

                        function actualizarTipoGrafica(nombreGrafica) {
                          var tipoGrafica = document.getElementById("tipoGrafica" + nombreGrafica).value;
                          
                          charts[nombreGrafica].config.type = tipoGrafica;
                          charts[nombreGrafica].update();
                      }

                        function actualizarDatosGrafica(nombreGrafica) {
                            let data = ' . json_encode($datos_grafica) . ';
                            let fechas = Object.keys(data);
                            
                            // Obtener las fechas seleccionadas por el usuario
                            let startDate = document.getElementById("start-date" + nombreGrafica).value;
                            let endDate = document.getElementById("end-date" + nombreGrafica).value;

                            // Filtrar el array de fechas
                            let fechasFiltradas = fechas.filter(fecha => {
                                return fecha >= startDate && fecha <= endDate;
                            });

                            console.log(data);
                            console.log(fechas);
                            console.log(startDate);
                            console.log(endDate);
                            console.log(fechasFiltradas);
                            charts[nombreGrafica].config.data.labels = fechasFiltradas;
                            charts[nombreGrafica].update();
                        }

                        function inicializarGrafico(nombreGrafica) {
                            var ctx = document.getElementById("Grafica" + nombreGrafica).getContext("2d");

                            var data = ' . json_encode($datos_grafica) . ';
                            var labels = Object.keys(data);
                            var values = Object.values(data);

                            return new Chart(ctx, {
                                type: "line",
                                data: {
                                    labels: labels,
                                    datasets: [{
                                        label: "' . $dispositivo['dispositivo'] . ' (' . $dispositivo['unidad_de_medida'] .')",
                                        data: values,
                                        backgroundColor: "rgb(128, 128, 128)",
                                        borderColor: "rgb(57, 169, 0)",
                                        borderWidth: 2
                                    }]
                                },
                                options: {
                                    scales: {
                                        x: {
                                          title: {
                                            display: true,
                                            text: "Fechas"
                                          }
                                        },
                                        y: {
                                            title: {
                                              display: true,
                                              text: "' . $dispositivo['unidad_de_medida'] .'"
                                            },
                                            beginAtZero: true
                                        }
                                    },
                                    plugins: {
                                      legend: {
                                        display: true,
                                        position: "top"
                                      }
                                    },
                                    maintainAspectRatio: false
                                }
                            });
                        }
                      </script>';

                    echo '<!-- Modal de Eliminar -->
                          <div class="modal fade" id="modalEliminar' . $chartId .'" tabindex="-1" aria-labelledby="exampleModalLabel"
                                    aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5" id="exampleModalLabel">Eliminar dispositivo</h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <form action="eliminacion_dispositivo.php" method="post">
                                                    <div class="mb-3">
                                                        <label for="exampleInputPassword1" class="form-label">¿Estás seguro que deseas eliminar el dispositivo?</label>
                                                        <input type="hidden" name="id_dispositivo" id="id_dispositivo" value="' . $dispositivo['id_dispositivo'] . '">
                                                        <input type="hidden" name="nombre_tabla" value="' . $chartId . '">
                                                    </div>
                                                    <button type="submit" class="btn botonv">Eliminar</button>
                                                </form>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn botong" data-bs-dismiss="modal">Cancelar</button>
                                            </div>
                                        </div>
                                    </div>
                        </div>';
                }
            }
          } else{
            echo '<p>Aún no has agregado dispositivos a esta unidad</p>';
          }
          echo '<div class="card text-center m-3" style="width: 15rem;">';
          echo '<div class="card-header bg-transparent border-success">';
          echo '<h5 class="card-title">Agregar Dispositivo</h5>';
          echo '</div>';
          echo '<div class="card-body">';
          echo '</div>';
          echo '<div class="card-footer bg-transparent border-success">';
          echo '<button type="button" class="btn plantilla text-center" data-bs-toggle="modal" data-bs-target="#exampleModal">Agregar
          </button>';
          echo '</div>';
          echo '</div>';
        }
      } else {
        echo "<h3>No se encontraron unidades</h3>";
      }
      
      // Cerrar la conexión
      $conn->close();
      ?>
    </div>
  </div>
  
  <script src="../js/dispositivos.js"></script>
  <script src="../js/code.jquery.com_jquery-3.7.0.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>