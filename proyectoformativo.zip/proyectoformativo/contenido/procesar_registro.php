<?php
// Incluir el archivo de conexión a la base de datos
require_once 'conexion.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Obtener los datos del formulario
$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
$usuario = $_POST['usuario'];
$email = $_POST['email'];
$contrasena = $_POST['contrasena'];
$unidad = $_POST['unidad'];
$rol = 'usuario';

// Insertar el nuevo usuario en la base de datos
$sql = "INSERT INTO usuarios (nombre, apellido, usuario, email, contrasena, rol, unidad) VALUES ('$nombre', '$apellido', '$usuario', '$email', '$contrasena', '$rol', '$unidad')";

if ($conn->query($sql) === TRUE) {
    echo "Usuario registrado correctamente";
    header("Location: inicio.php");
} else {
    echo "Error al registrar el usuario: " . $conn->error;
}

// Cerrar la conexión a la base de datos
$conn->close();
?>
