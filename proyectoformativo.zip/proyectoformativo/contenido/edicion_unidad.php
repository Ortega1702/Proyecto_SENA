<?php
require_once 'conexion.php'; // Asegúrate de incluir tu archivo de conexión

// Obtener el ID y el nombre de la unidad desde el formulario
$id_unidad = $_POST['id_unidad'];
$nombre = $_POST['nombre'];
echo''.$id_unidad.'';

// Actualizar el nombre en la base de datos
$sql = "UPDATE unidades SET nombre='$nombre' WHERE id=$id_unidad";

if ($conn->query($sql) === TRUE) {
    echo "Nombre actualizado correctamente.";
    header("Location: unidades.php");
    exit();
} else {
    echo "<script>alert('Error al actualizar unidad')</script>";
}

$conn->close();
?>
