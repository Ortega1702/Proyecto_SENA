<?php
require_once 'conexion.php'; 

// Obtener el ID y el nombre de la unidad desde el formulario
$id = $_POST['id_hardware'];
$nombre = $_POST['nombre'];

// Actualizar el nombre en la base de datos
$sql = "UPDATE hardware SET nombre='$nombre' WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    echo "Nombre actualizado correctamente.";
    header("Location: unidades.php");
    exit();
} else {
    echo "<script>alert('Error al actualizar hardware')</script>";
}

$conn->close();
?>
