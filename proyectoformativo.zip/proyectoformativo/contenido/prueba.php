<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/prueba.css">
</head>

<body>

    <a href="javascript:history.back()"><img src="../images/hacia-atras.png" alt="Botón" class="volver mt-2"> </a>

    <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel"></h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </div>
    <div class="modal-body">
    </div>
    <div class="modal-footer">
        <button type="button" class="btn botong" data-bs-dismiss="modal">Cancelar</button>
    </div>
    <script src="../js/dispositivos.js"></script><
</body>

</html>