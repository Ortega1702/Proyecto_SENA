<?php 
require_once 'conexion.php';

$desde = $_POST['fecha_desde'];
$hasta = $_POST['fecha_hasta'];
$nombre_tabla = $_POST['nombre_tabla'];
$dispositivo = $_POST['dispositivo'];
$id_usuario = $_POST['id_usuario'];

// Consulta para obtener los datos (ejemplo)
$sql_datos = "SELECT fecha, " . $dispositivo . " FROM " . $nombre_tabla . " WHERE fecha BETWEEN '" . $desde . "' AND '" . $hasta . "'";
$result_datos = $conn->query($sql_datos);

// Crear un array con los datos
$data = [];
if ($result_datos->num_rows > 0) {
    while ($row = $result_datos->fetch_assoc()) {
        $data[$row["fecha"]] = $row[$dispositivo];
    }
} 

// Nombre del archivo CSV de ejemplo
$nombre_archivo = "datos.csv";

// Encabezados para forzar la descarga del archivo
header('Content-Type: application/csv');
header('Content-Disposition: attachment; filename="' . $nombre_archivo . '"');

// Abre el archivo en modo de escritura
$archivo = fopen('php://output', 'w');

fputcsv($archivo, array('________FECHA________', $dispositivo));
foreach ($data as $key => $value) {
    fputcsv($archivo, array($key, $value));
}

//Cierra el archivo
fclose($archivo);
?>