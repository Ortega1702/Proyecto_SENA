<?php
// Conexión a la base de datos
require_once 'conexion.php';

// Recibe los datos POST
$id_dispositivo = 49;

// Validar la existencia de 'temperatura' y que es un número
if (isset($_POST['temperatura']) && is_numeric($_POST['temperatura'])) {
    $temperatura = $_POST['temperatura'];
} else {
    echo "Error: Datos de temperatura no válidos";
}

// Prepara la consulta SQL con un marcador de posición (?)
$sql = "INSERT INTO temperatura11 (id_dispositivo, fecha, Temperatura) VALUES (?, now(), ?)";

// Prepara la declaración
$stmt = $conn->prepare($sql);

// Vincula los parámetros y ejecuta la consulta
$stmt->bind_param("is", $id_dispositivo, $temperatura);

if ($stmt->execute()) {
    echo "Datos insertados correctamente";
} else {
    echo "Error al insertar datos: " . $stmt->error;
}

// Cierra la declaración
$stmt->close();
?>