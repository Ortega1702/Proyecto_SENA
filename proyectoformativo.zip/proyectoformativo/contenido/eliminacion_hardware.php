<?php
require_once 'conexion.php'; 

// Obtener el ID de la unidad desde el formulario
$id = $_POST['id_hardware'];

// Eliminar la unidad en la base de datos
$sql = "DELETE FROM hardware WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    echo "Hardware eliminado correctamente.";
    header("Location: unidades.php");
    exit();
} else {
    echo "<script>alert('Error al eliminar el hardware')</script>";
}

$conn->close();
?>
