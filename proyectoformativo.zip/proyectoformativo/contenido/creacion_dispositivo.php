<?php
session_start();

// Incluir el archivo de conexión a la base de datos
require_once 'conexion.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);
try {
  $id_usuario = $_SESSION['id_usuario'];

  // Obtener los datos del formulario
  $nombre = $_POST['nombre'];
  $hardware = $_POST['hardware'];
  $descripcion = $_POST['descripcion'];

  if ($_SERVER["REQUEST_METHOD"] == "POST") {
      $unidad_seleccionada_id = $_POST['unidades_listbox'];
  }

  // Insertar el nuevo dispositivo en la base de datos
  $sql = "INSERT INTO dispositivos (nombre, hardware, id_unidad, descripcion, id_usuario) VALUES ('$nombre', '$hardware', '$unidad_seleccionada_id', '$descripcion', '$id_usuario')";

  if ($conn->query($sql) === TRUE) {
      // Obtener el ID del dispositivo recién insertado
      $id_dispositivo = $conn->insert_id;

      // Crear una nueva tabla con el ID del dispositivo
      $sql_nueva_tabla = "CREATE TABLE $nombre" . $id_usuario . " (
          id_dato INT AUTO_INCREMENT PRIMARY KEY,
          id_dispositivo INT,
          fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          $nombre DECIMAL(10, 2),
          FOREIGN KEY (id_dispositivo) REFERENCES dispositivos(id)
      )";

      if ($conn->query($sql_nueva_tabla) === TRUE) {
          echo 'Dispositivo y tabla de datos creados con éxito';
          header("Location: dispositivos.php");
          exit();
      } else {
          echo "<script>alert('Error al crear la tabla de datos')</script>";
      }
  } else {
      echo "Error al crear dispositivo";
  }
} catch (Exception $e) {
  echo "Error al crear dispositivo: " . $e->getMessage() . "";
}
// Cerrar la conexión a la base de datos
$conn->close();
?>


