<?php
session_start();
// Incluir el archivo de conexión a la base de datos
require_once 'conexion.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

$id_usuario = $_SESSION['id_usuario'];

// Obtener los datos del formulario
$nombre = $_POST['nombre'];
$hardware = $_POST['hardware'];
$descripcion = $_POST['descripcion'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $unidad_seleccionada_id = $_POST['unidades_listbox'];
    $unidad_seleccionada_nombre = '';
  
    // Buscar el nombre de la unidad seleccionada
    foreach($unidades as $unidad) {
      if ($unidad['id'] == $unidad_seleccionada_id) {
        $unidad_seleccionada_nombre = $unidad['nombre'];
        break;
      }
    }
}

// Insertar el nuevo usuario en la base de datos
$sql = "INSERT INTO dispositivos (nombre, hardware, id_unidad, descripcion, id_usuario) VALUES ('$nombre', '$hardware', '$unidad_seleccionada_id', '$descripcion', '$id_usuario')";

if ($conn->query($sql) === TRUE) {
    echo 'Dispositivo creado con éxito';
    header("Location: dispositivos.php");
    exit();
} else {
    echo "<script>alert('Error al crear dispositivo')</script>";
}

// Cerrar la conexión a la base de datos
$conn->close();
?>


