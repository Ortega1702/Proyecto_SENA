<script>
    var miSelect = document.getElementById("unidad_select");
    var unidadSeleccionada = document.getElementById("unidad_seleccionada");

    miSelect.addEventListener("change", function() {
      unidadSeleccionada.value = miSelect.value;
      miSelect.form.submit(); // Envía el formulario
    });
</script>