<?php
require_once 'conexion.php'; // Asegúrate de incluir tu archivo de conexión

// Obtener datos desde el formulario
$id_dispositivo = $_POST['id_dispositivo'];
$nombre_tabla = $_POST['nombre_tabla'];

//Eliminar la tabla del dispositivo de la base de datos
$sql_tabla = 'DROP TABLE ' . $nombre_tabla . ';';

// Eliminar el dispositivo en la base de datos
$sql_dispositivo = "DELETE FROM dispositivos WHERE id=$id_dispositivo";

if ($conn->query($sql_tabla) === TRUE and $conn->query($sql_dispositivo) === TRUE) {
    echo "Dispositivo eliminado correctamente.";
    header("Location: dispositivos.php");
    exit();
} else {
    echo "<script>alert('Error al eliminar el dispositivo')</script>";
}

$conn->close();
?>
