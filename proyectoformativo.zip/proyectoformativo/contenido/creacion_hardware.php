<?php
session_start();
// Incluir el archivo de conexión a la base de datos
require_once 'conexion.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Obtener los datos del formulario
$nombre = $_POST['nombre'];

// Insertar el nuevo usuario en la base de datos
$sql = "INSERT INTO hardware (nombre) VALUES ('$nombre')";

if ($conn->query($sql) === TRUE) {
    echo 'Hardware creado con éxito';
    header("Location: unidades.php");
    exit();
} else {
    echo "<script>alert('Error al crear hardware')</script>";
}

// Cerrar la conexión a la base de datos
$conn->close();
?>
