<?php
require_once 'conexion.php'; // Asegúrate de incluir tu archivo de conexión

// Obtener el ID de la unidad desde el formulario
$id_unidad = $_POST['id_unidad'];

// Eliminar la unidad en la base de datos
$sql = "DELETE FROM unidades WHERE id=$id_unidad";

if ($conn->query($sql) === TRUE) {
    echo "Unidad eliminada correctamente.";
    header("Location: unidades.php");
    exit();
} else {
    echo "<script>alert('Error al eliminar la unidad')</script>";
}

$conn->close();
?>
