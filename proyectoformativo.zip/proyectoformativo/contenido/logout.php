<?php
    session_start();

    if (isset($_SESSION['loggedin'])) {
        // El usuario ha iniciado sesión, procede a cerrar sesión.
        session_destroy();
        header("Location: inicio.php");
        exit();
    } else {
        // Redirige a la página de inicio de sesión si el usuario no está autenticado.
        header("Location: inicio.php");
        exit();
    }
?>